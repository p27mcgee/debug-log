
Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/com.contrastsecurity.agent.test.junit.containers.AcceptanceTestClassExtensionIntegrationTest_RepeatedTestSample-20241021T192306.650.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/com.contrastsecurity.agent.test.junit.containers.AcceptanceTestClassExtensionIntegrationTest_RepeatedTestSample-20241021T192306.650.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingAcceptanceTest-20241021T192348.034.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingAcceptanceTest-20241021T192348.034.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingParameterizedAcceptanceTest-20241021T192405.942.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingParameterizedAcceptanceTest-20241021T192405.942.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedMethod-20241021T192423.715.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedMethod-20241021T192423.715.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedMethod-20241021T192441.340.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedMethod-20241021T192441.340.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedParameterizedMethod-20241021T192459.074.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedParameterizedMethod-20241021T192459.074.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedParameterizedMethod-20241021T192516.859.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedParameterizedMethod-20241021T192516.859.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/com.contrastsecurity.agent.test.junit.containers.AcceptanceTestClassExtensionIntegrationTest_RepeatedTestSample-20241021T193406.435.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/com.contrastsecurity.agent.test.junit.containers.AcceptanceTestClassExtensionIntegrationTest_RepeatedTestSample-20241021T193406.435.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingAcceptanceTest-20241021T193447.557.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingAcceptanceTest-20241021T193447.557.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingParameterizedAcceptanceTest-20241021T193505.727.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.EnabledTestEventsIntegrationTest_WorkingParameterizedAcceptanceTest-20241021T193505.727.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedMethod-20241021T193523.450.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedMethod-20241021T193523.450.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedMethod-20241021T193540.953.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedMethod-20241021T193540.953.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedParameterizedMethod-20241021T193559.091.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_KnownIssuesAnnotatedParameterizedMethod-20241021T193559.091.zip</li>
</ul>
</details>

Build Artifacts can be downloaded from s3 via `aws s3 cp`. For example:

```
aws s3 cp s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedParameterizedMethod-20241021T193616.616.zip $HOME/Downloads/.
```

<details>
<summary>Acceptance Test Artifact S3 URLs</summary>
<ul>
<li>s3://test-application-cloud-test-artifacts/actions/runs/11447124118/attempts/1/iterations/acceptance-test-artifacts/fake.acceptance.tests.SkippedTestEventsIntegrationTests_NotYetImplementedAnnotatedParameterizedMethod-20241021T193616.616.zip</li>
</ul>
</details>
